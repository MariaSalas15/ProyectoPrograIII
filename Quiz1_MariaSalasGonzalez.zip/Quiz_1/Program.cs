﻿// Universidad Nacional / Escuela de Informatica
// EIF-206 Programacion III / Quiz 1
// Academico: Walter Leon Chavarria / Estudiante: Maria Salas Gonzalez
// I Ciclo 2020

using System;
using c1; 
namespace Quiz_1{
    class Program{
        static void Main(string[] args){
            Contador con = new Contador();
            con.contadorMultiplo();
        }
    }
}
